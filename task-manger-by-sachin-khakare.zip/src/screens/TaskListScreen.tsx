import React, { useEffect } from "react";
import { FlatList, Button, View } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { v4 as uuidv4 } from "uuid"; // for unique IDs
import { RootState, AppDispatch } from "../store";
import {
  addTask,
  deleteTask,
  toggleStatus,
  fetchTasks,
} from "../store/tasksSlice";
import { TaskItem } from "../components/TaskItem";

export const TaskListScreen = () => {
  const dispatch = useDispatch<AppDispatch>();
  const tasks = useSelector((state: RootState) => state.tasks.tasks);

  useEffect(() => {
    dispatch(fetchTasks()); // make sure fetchTasks is an exported thunk
  }, [dispatch]);

  const handleAddTask = () => {
    const newTask = {
      id: uuidv4(), // unique ID
      title: "New Task",
      description: "Task description",
      completed: false,
    };
    dispatch(addTask(newTask));
  };

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Button title="Add Task" onPress={handleAddTask} />

      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TaskItem
            task={item}
            onToggle={() => dispatch(toggleStatus(item.id))}
            onDelete={() => dispatch(deleteTask(item.id))}
          />
        )}
        contentContainerStyle={{ paddingVertical: 8 }}
      />
    </View>
  );
};
