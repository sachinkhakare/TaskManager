import React from "react";
import { View, Text, Button, Alert } from "react-native";
import { Task } from "../types/Task";

interface Props {
  task: Task;
  onToggle: () => void;
  onDelete: () => void;
}

export const TaskItem: React.FC<Props> = ({ task, onToggle, onDelete }) => {
  return (
    <View style={{ padding: 10, borderBottomWidth: 1 }}>
      <Text>{task.title}</Text>
      <Text>{task.description}</Text>
      <Text>Status: {task.status}</Text>
      <Button title="Toggle Status" onPress={onToggle} />
      <Button
        title="Delete"
        color="red"
        onPress={() =>
          Alert.alert("Confirm", "Delete this task?", [
            { text: "Cancel" },
            { text: "Delete", onPress: onDelete },
          ])
        }
      />
    </View>
  );
};
