import { createSlice, PayloadAction, createAsyncThunk } from "@reduxjs/toolkit";
import { Task } from "../types/Task";
import { loadTasks, saveTasks } from "../utils/storage";
import { v4 as uuid } from "uuid";

interface TaskState {
  tasks: Task[];
}

const initialState: TaskState = {
  tasks: [],
};

// Async thunk to load tasks
export const fetchTasks = createAsyncThunk<Task[]>("tasks/load", async () => {
  const tasks = await loadTasks();
  return tasks;
});

const tasksSlice = createSlice({
  name: "tasks",
  initialState,
  reducers: {
    addTask: (
      state,
      action: PayloadAction<{ title: string; description: string }>
    ) => {
      const newTask: Task = {
        id: uuid(),
        title: action.payload.title,
        description: action.payload.description,
        status: "Pending",
        createdAt: new Date().toISOString(),
      };
      state.tasks.push(newTask);
      saveTasks(state.tasks);
    },
    updateTask: (state, action: PayloadAction<Task>) => {
      const index = state.tasks.findIndex((t) => t.id === action.payload.id);
      if (index !== -1) {
        state.tasks[index] = action.payload;
        saveTasks(state.tasks);
      }
    },
    deleteTask: (state, action: PayloadAction<string>) => {
      state.tasks = state.tasks.filter((task) => task.id !== action.payload);
      saveTasks(state.tasks);
    },
    toggleStatus: (state, action: PayloadAction<string>) => {
      const task = state.tasks.find((t) => t.id === action.payload);
      if (task) {
        task.status = task.status === "Pending" ? "Completed" : "Pending";
        saveTasks(state.tasks);
      }
    },
  },
  extraReducers: (builder) => {
    builder.addCase(
      fetchTasks.fulfilled,
      (state, action: PayloadAction<Task[]>) => {
        state.tasks = action.payload;
      }
    );
  },
});

export const { addTask, updateTask, deleteTask, toggleStatus } =
  tasksSlice.actions;
export default tasksSlice.reducer;
